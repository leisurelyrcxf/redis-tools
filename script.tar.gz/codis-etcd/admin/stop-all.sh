#!/bin/bash
./codis-dashboard-admin.sh stop
./codis-fe-admin.sh stop
./codis-proxy-admin-1.sh stop
./codis-proxy-admin-2.sh stop
#./pika-admin-56379.sh stop
#./pika-admin-56380.sh stop
ps -aux | grep pika | grep -v grep | awk '{print $2}' | xargs safe-kill
