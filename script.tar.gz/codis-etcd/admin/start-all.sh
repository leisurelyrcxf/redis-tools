#!/bin/bash

set -x

etcd_pid=`pgrep etcd`
if [ "$etcd_pid" = "" ]; then
   ~/vitess/bin/etcd-up.sh
fi


codis_dashboard_pid=`pgrep codis-dashboard`
if [ "$codis_dashboard_pid" = "" ]; then
    ./codis-dashboard-admin.sh start
fi

./codis-proxy-admin-1.sh start

./codis-proxy-admin-2.sh start

pika_pid=`ps -axu | grep pika | grep 56380`
if [ "$pika_pid" = "" ]; then
    ./pika-admin-56380.sh start
fi
pika_pid=`ps -axu | grep pika | grep 56381`
if [ "$pika_pid" = "" ]; then
    ./pika-admin-56381.sh start
fi
pika_pid=`ps -axu | grep pika | grep 56382`
if [ "$pika_pid" = "" ]; then
    ./pika-admin-56382.sh start
fi

codis_fe_pid=`pgrep codis-fe`
if [ "$codis_fe_pid" = "" ]; then
    ./codis-fe-admin.sh start
fi
