#!/usr/bin/env bash

CODIS_ADMIN="${BASH_SOURCE-$0}"
CODIS_ADMIN="$(dirname "${CODIS_ADMIN}")"
CODIS_ADMIN_DIR="$(cd "${CODIS_ADMIN}"; pwd)"

CODIS_BIN_DIR=$CODIS_ADMIN_DIR/../bin
CODIS_LOG_DIR=$CODIS_ADMIN_DIR/../log
CODIS_CONF_DIR=$CODIS_ADMIN_DIR/../config

PIKA_BIN=$CODIS_BIN_DIR/pika
PIKA_PID_FILE=$CODIS_ADMIN_DIR/../pid/pika-56381.pid

PIKA_LOG_FILE=/tmp/pika-56381.log
PIKA_DAEMON_FILE=$CODIS_LOG_DIR/pika-56381.out

PIKA_CONF_FILE=$CODIS_CONF_DIR/pika-56381.conf

echo $PIKA_CONF_FILE

if [ ! -d $CODIS_LOG_DIR ]; then
    mkdir -p $CODIS_LOG_DIR
fi


case $1 in
start)
    echo  "starting pika ... "
    if [ -f "$PIKA_PID_FILE" ]; then
      if kill -0 `cat "$PIKA_PID_FILE"` > /dev/null 2>&1; then
         echo $command already running as process `cat "$PIKA_PID_FILE"`.
         exit 0
      fi
    fi
    nohup "$PIKA_BIN" -c "${PIKA_CONF_FILE}" > "$PIKA_DAEMON_FILE" 2>&1 < /dev/null &
    ;;
stop)
    echo "stopping pika ... "
    if [ ! -f "$PIKA_PID_FILE" ]
    then
      echo "no pika to stop (could not find file $PIKA_PID_FILE)"
    else
      kill -2 $(cat "$PIKA_PID_FILE")
      echo STOPPED
    fi
    exit 0
    ;;
stop-forced)
    echo "stopping pika ... "
    if [ ! -f "$PIKA_PID_FILE" ]
    then
      echo "no pika to stop (could not find file $PIKA_PID_FILE)"
    else
      kill -9 $(cat "$PIKA_PID_FILE")
      rm "$PIKA_PID_FILE"
      echo STOPPED
    fi
    exit 0
    ;;
restart)
    shift
    "$0" stop
    sleep 1
    "$0" start
    ;;
*)
    echo "Usage: $0 {start|stop|stop-forced|restart}" >&2

esac
